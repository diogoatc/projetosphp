<?php

$nomes = array("ANITA","JOAO","PEDRO","MARIA","FILIPE","ANGELA","ANA","REGINA","LUIZ","TEREZA");

foreach ($nomes as $valores){
	
	echo $valores."<br/>";
}

?>