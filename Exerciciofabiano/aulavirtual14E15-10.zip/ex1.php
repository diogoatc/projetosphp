<?php

$nomes = array("GUTO GARCIA","PEDRO CORREA","ANITA LOPES","MARIA CORREA","JOAO BOND");
asort($nomes); //Fun��o para colocar em ordem alfab�tica os nomes

foreach ($nomes as $chave){
	echo "$chave"."<br/>";
}



?>
